package me.flashyreese.mods.reeses_sodium_options.client.gui;

public interface FlatButtonWidgetExtended {
    boolean isLeftAligned();

    void setLeftAligned(boolean leftAligned);
}
