package me.flashyreese.mods.reeses_sodium_options.client.gui;

public interface SliderControlElementExtended {
    boolean isEditMode();

    void setEditMode(boolean editMode);
}
