package me.jellysquid.mods.sodium.client.render.texture;

public interface SpriteContentsExtended {
    void setActive(boolean b);

    boolean hasAnimation();

    boolean isActive();
}
