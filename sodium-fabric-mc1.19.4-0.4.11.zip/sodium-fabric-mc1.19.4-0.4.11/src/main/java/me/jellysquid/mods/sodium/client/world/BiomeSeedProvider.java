package me.jellysquid.mods.sodium.client.world;

public interface BiomeSeedProvider {
    long getBiomeSeed();
}
