package me.jellysquid.mods.sodium.client.render.chunk.vertex.format;

public enum ChunkMeshAttribute {
    POSITION_MATERIAL_MESH,
    COLOR_SHADE,
    BLOCK_TEXTURE,
    LIGHT_TEXTURE
}
