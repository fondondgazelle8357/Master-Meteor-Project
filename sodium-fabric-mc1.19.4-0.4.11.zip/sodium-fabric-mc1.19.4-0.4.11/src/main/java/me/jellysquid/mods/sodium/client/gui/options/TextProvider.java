package me.jellysquid.mods.sodium.client.gui.options;

import net.minecraft.text.Text;

public interface TextProvider {
    Text getLocalizedName();
}
