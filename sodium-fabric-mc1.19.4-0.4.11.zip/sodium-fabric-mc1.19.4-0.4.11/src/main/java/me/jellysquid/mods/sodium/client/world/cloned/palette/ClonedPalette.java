package me.jellysquid.mods.sodium.client.world.cloned.palette;

public interface ClonedPalette<K> {
    K get(int id);
}
