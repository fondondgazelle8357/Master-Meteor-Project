package me.jellysquid.mods.sodium.client.gl.util;

public record VertexRange(int vertexStart, int vertexCount) {
}
