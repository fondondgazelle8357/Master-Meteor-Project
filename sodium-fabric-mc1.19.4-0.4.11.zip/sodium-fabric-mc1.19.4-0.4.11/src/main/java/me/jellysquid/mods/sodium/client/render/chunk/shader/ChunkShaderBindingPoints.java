package me.jellysquid.mods.sodium.client.render.chunk.shader;

public class ChunkShaderBindingPoints {
    public static final int ATTRIBUTE_POSITION_ID = 1;
    public static final int ATTRIBUTE_COLOR = 2;
    public static final int ATTRIBUTE_BLOCK_TEXTURE = 3;
    public static final int ATTRIBUTE_LIGHT_TEXTURE = 4;

    public static final int FRAG_COLOR = 0;
}
