package ru.feytox.toomanyplayers.gui;

import io.github.cottonmc.cotton.gui.GuiDescription;
import io.github.cottonmc.cotton.gui.client.CottonClientScreen;

public class GuiScreen extends CottonClientScreen {
    public GuiScreen(GuiDescription description) {
        super(description);
    }
}
