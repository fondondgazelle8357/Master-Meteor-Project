package ru.feytox.toomanyplayers.commands;

public enum TMPlistTypes {
    WHITELIST, BLOCKLIST, HIDESKINLIST
}
