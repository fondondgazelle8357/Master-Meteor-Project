/**
 * This package includes various world chunk related optimizations.
 */
@MixinConfigOption(description = "Various world chunk optimizations")
package me.jellysquid.mods.lithium.mixin.chunk;

import net.caffeinemc.gradle.MixinConfigOption;