@MixinConfigOption(description = "Improve the BlockState withTable lookup by using a custom table implementation.")
package me.jellysquid.mods.lithium.mixin.alloc.blockstate;

import net.caffeinemc.gradle.MixinConfigOption;