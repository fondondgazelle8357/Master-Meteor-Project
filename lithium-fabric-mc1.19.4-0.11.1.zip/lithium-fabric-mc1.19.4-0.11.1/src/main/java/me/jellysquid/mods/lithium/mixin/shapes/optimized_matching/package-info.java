@MixinConfigOption(description = "VoxelShape collisions use a faster intersection test for cuboid shapes")
package me.jellysquid.mods.lithium.mixin.shapes.optimized_matching;

import net.caffeinemc.gradle.MixinConfigOption;