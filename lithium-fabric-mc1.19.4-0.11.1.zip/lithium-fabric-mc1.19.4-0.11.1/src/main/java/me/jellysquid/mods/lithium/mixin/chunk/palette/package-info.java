@MixinConfigOption(description = "Replaces the vanilla hash palette with an optimized variant")
package me.jellysquid.mods.lithium.mixin.chunk.palette;

import net.caffeinemc.gradle.MixinConfigOption;