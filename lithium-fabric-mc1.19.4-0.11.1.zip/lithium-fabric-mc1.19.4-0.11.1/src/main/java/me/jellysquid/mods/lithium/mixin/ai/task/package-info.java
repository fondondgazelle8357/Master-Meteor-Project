@MixinConfigOption(description = "Various AI task optimizations")
package me.jellysquid.mods.lithium.mixin.ai.task;

import net.caffeinemc.gradle.MixinConfigOption;