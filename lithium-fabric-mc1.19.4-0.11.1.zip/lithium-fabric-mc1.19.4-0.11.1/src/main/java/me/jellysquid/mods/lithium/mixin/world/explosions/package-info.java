@MixinConfigOption(description = "Various improvements to explosions, e.g. not accessing blocks along an explosion ray multiple times")
package me.jellysquid.mods.lithium.mixin.world.explosions;

import net.caffeinemc.gradle.MixinConfigOption;