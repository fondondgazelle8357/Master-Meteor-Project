package me.jellysquid.mods.lithium.common.block;

public interface BlockStateFlagHolder {
    int getAllFlags();
}
