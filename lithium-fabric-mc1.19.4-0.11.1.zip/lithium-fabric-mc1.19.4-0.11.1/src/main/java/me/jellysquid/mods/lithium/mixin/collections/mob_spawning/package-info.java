@MixinConfigOption(description = "Uses custom hashset/list combination for faster mob spawn checks")
package me.jellysquid.mods.lithium.mixin.collections.mob_spawning;

import net.caffeinemc.gradle.MixinConfigOption;