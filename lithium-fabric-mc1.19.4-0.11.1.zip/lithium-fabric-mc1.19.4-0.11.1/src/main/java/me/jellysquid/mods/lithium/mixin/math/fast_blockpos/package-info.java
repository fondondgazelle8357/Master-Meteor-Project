@MixinConfigOption(description = "Avoids indirection and inlines several functions")
package me.jellysquid.mods.lithium.mixin.math.fast_blockpos;

import net.caffeinemc.gradle.MixinConfigOption;