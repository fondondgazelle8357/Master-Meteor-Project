@MixinConfigOption(
        description = "Access chunks of worlds, chunk caches and chunk regions directly."
)
package me.jellysquid.mods.lithium.mixin.util.chunk_access;

import net.caffeinemc.gradle.MixinConfigOption;
