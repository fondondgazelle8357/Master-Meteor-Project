@MixinConfigOption(description = "Replace Stream code of AI tasks with more traditional iteration.")
package me.jellysquid.mods.lithium.mixin.ai.task.replace_streams;

import net.caffeinemc.gradle.MixinConfigOption;