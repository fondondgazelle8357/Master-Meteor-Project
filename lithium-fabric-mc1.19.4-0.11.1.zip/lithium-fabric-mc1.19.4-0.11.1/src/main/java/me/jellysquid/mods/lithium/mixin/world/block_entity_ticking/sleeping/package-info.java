@MixinConfigOption(description = "Allows BlockEntities to sleep, meaning they are no longer ticked until woken up, e.g. by updates to their inventory or block state")
package me.jellysquid.mods.lithium.mixin.world.block_entity_ticking.sleeping;

import net.caffeinemc.gradle.MixinConfigOption;