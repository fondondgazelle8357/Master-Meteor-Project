@MixinConfigOption(description = "Various math optimizations")
package me.jellysquid.mods.lithium.mixin.math;

import net.caffeinemc.gradle.MixinConfigOption;