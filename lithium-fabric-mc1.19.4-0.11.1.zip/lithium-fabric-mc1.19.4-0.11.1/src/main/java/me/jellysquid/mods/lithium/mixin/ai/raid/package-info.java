@MixinConfigOption(description = "Avoids unnecessary raid bar updates and optimizes expensive leader banner operations")
package me.jellysquid.mods.lithium.mixin.ai.raid;

import net.caffeinemc.gradle.MixinConfigOption;