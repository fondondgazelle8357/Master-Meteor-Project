@MixinConfigOption(description = "Use ReferenceArraySet instead of HashSet to store the fluids the entity is currently submerged in.")
package me.jellysquid.mods.lithium.mixin.collections.fluid_submersion;

import net.caffeinemc.gradle.MixinConfigOption;