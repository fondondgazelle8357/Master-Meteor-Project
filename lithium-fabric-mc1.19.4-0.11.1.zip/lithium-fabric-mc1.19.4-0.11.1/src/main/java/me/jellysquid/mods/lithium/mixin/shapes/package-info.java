@MixinConfigOption(description = "Various VoxelShape optimizations")
package me.jellysquid.mods.lithium.mixin.shapes;

import net.caffeinemc.gradle.MixinConfigOption;