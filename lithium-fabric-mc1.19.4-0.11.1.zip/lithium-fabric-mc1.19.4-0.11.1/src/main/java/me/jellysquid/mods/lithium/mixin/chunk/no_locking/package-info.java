@MixinConfigOption(description = "Remove debug checks in block access code")
package me.jellysquid.mods.lithium.mixin.chunk.no_locking;

import net.caffeinemc.gradle.MixinConfigOption;