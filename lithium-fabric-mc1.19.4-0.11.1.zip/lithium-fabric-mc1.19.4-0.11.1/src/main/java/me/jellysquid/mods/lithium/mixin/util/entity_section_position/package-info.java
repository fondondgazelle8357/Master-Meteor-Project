@MixinConfigOption(description = "Entity sections store their position")
package me.jellysquid.mods.lithium.mixin.util.entity_section_position;

import net.caffeinemc.gradle.MixinConfigOption;