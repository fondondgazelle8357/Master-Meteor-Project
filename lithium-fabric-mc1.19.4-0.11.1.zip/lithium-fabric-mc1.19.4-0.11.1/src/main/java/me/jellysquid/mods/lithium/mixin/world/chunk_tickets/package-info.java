@MixinConfigOption(description = "Improves the chunk ticket sets by speeding up the removal of chunk tickets")
package me.jellysquid.mods.lithium.mixin.world.chunk_tickets;

import net.caffeinemc.gradle.MixinConfigOption;