@MixinConfigOption(description = "Merging and intersecting VoxelShapes is optimized using faster position list merging")
package me.jellysquid.mods.lithium.mixin.shapes.shape_merging;

import net.caffeinemc.gradle.MixinConfigOption;