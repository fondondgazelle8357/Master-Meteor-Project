@MixinConfigOption(description = "Portal search uses the faster POI search")
package me.jellysquid.mods.lithium.mixin.ai.poi.fast_portals;

import net.caffeinemc.gradle.MixinConfigOption;