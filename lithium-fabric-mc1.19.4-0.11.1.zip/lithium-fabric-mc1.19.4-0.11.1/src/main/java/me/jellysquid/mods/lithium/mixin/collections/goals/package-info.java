@MixinConfigOption(description = "Uses fastutil hashsets for goals in the AI goal selector")
package me.jellysquid.mods.lithium.mixin.collections.goals;

import net.caffeinemc.gradle.MixinConfigOption;