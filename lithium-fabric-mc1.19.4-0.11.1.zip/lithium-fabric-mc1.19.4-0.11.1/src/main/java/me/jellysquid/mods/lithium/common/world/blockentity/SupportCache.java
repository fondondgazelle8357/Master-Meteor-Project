package me.jellysquid.mods.lithium.common.world.blockentity;

public interface SupportCache {
    boolean isSupported();
}
