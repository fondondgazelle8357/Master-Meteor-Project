package me.jellysquid.mods.lithium.common.entity.movement_tracker;

public interface SectionedEntityMovementListener {

    void handleEntityMovement(Class<?> category);

}
