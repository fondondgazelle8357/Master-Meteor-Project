@MixinConfigOption(description = "Various utilities for other mixins")
package me.jellysquid.mods.lithium.mixin.util;

import net.caffeinemc.gradle.MixinConfigOption;