@MixinConfigOption(description = "Various BlockEntity ticking optimizations")
package me.jellysquid.mods.lithium.mixin.world.block_entity_ticking;

import net.caffeinemc.gradle.MixinConfigOption;