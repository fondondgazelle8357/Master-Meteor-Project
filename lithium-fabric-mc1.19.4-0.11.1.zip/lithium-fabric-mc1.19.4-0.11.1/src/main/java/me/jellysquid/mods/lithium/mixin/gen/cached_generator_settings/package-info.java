@MixinConfigOption(
        description = "World generator settings cache the sea level",
        enabled = false
)
package me.jellysquid.mods.lithium.mixin.gen.cached_generator_settings;

import net.caffeinemc.gradle.MixinConfigOption;