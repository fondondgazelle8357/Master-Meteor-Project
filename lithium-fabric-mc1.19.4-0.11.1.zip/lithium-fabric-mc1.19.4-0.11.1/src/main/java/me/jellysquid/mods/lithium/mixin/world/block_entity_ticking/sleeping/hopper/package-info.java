@MixinConfigOption(description = "BlockEntity sleeping for locked hoppers")
package me.jellysquid.mods.lithium.mixin.world.block_entity_ticking.sleeping.hopper;

import net.caffeinemc.gradle.MixinConfigOption;