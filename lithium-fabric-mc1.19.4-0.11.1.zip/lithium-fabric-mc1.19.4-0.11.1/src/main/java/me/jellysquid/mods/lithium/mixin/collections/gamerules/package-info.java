@MixinConfigOption(description = "Uses fastutil hashmaps for gamerules")
package me.jellysquid.mods.lithium.mixin.collections.gamerules;

import net.caffeinemc.gradle.MixinConfigOption;