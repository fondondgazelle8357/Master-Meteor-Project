@MixinConfigOption(description = "Copy entity hashmap instead of duplicating the list using iteration")
package me.jellysquid.mods.lithium.mixin.collections.entity_ticking;

import net.caffeinemc.gradle.MixinConfigOption;