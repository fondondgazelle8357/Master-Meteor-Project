@MixinConfigOption(description = "Reduces the sine table size to reduce memory usage and increase access speed")
package me.jellysquid.mods.lithium.mixin.math.sine_lut;

import net.caffeinemc.gradle.MixinConfigOption;