@MixinConfigOption(description = "Avoid unnecessary secondary POI searches of non-farmer villagers")
package me.jellysquid.mods.lithium.mixin.ai.sensor.secondary_poi;

import net.caffeinemc.gradle.MixinConfigOption;