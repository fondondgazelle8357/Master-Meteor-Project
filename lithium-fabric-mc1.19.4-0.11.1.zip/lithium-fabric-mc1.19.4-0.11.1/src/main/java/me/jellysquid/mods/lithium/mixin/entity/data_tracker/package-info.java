@MixinConfigOption(description = "Various entity data tracker optimizations")
package me.jellysquid.mods.lithium.mixin.entity.data_tracker;

import net.caffeinemc.gradle.MixinConfigOption;