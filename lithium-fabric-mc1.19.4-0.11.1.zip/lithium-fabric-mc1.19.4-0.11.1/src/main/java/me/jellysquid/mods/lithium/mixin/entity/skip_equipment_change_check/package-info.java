@MixinConfigOption(description = "Skips repeated checks whether the equipment of an entity changed. Instead equipment updates are detected")
package me.jellysquid.mods.lithium.mixin.entity.skip_equipment_change_check;

import net.caffeinemc.gradle.MixinConfigOption;