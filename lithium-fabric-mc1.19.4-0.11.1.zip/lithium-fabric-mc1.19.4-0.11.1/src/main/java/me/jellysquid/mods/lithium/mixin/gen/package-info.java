@MixinConfigOption(description = "Various world generation optimizations")
package me.jellysquid.mods.lithium.mixin.gen;

import net.caffeinemc.gradle.MixinConfigOption;