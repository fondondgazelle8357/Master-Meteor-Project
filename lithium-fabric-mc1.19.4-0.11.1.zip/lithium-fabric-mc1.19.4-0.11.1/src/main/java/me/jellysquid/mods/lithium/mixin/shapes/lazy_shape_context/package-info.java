@MixinConfigOption(description = "Entity shape contexts initialize rarely used fields only on first use")
package me.jellysquid.mods.lithium.mixin.shapes.lazy_shape_context;

import net.caffeinemc.gradle.MixinConfigOption;