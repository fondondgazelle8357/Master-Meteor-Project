@MixinConfigOption(description = "Skip searching for fire sources in the burn time countdown logic when they are not on fire and the result does not make a difference.")
package me.jellysquid.mods.lithium.mixin.entity.skip_fire_check;

import net.caffeinemc.gradle.MixinConfigOption;