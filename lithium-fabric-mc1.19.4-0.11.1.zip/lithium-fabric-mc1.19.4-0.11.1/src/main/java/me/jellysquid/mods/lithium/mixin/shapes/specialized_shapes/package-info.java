@MixinConfigOption(description = "Specialized VoxelShape implementations are used for cuboid and empty shapes. Collisions" +
        " with those shapes are optimized using a cuboid specific implementation")
package me.jellysquid.mods.lithium.mixin.shapes.specialized_shapes;

import net.caffeinemc.gradle.MixinConfigOption;