@MixinConfigOption(description = "Various entity collision optimizations")
package me.jellysquid.mods.lithium.mixin.entity.collisions;

import net.caffeinemc.gradle.MixinConfigOption;