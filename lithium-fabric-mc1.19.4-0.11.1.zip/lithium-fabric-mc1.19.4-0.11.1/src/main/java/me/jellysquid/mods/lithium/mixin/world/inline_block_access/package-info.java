@MixinConfigOption(description = "Faster block and fluid access due to inlining and reduced method size")
package me.jellysquid.mods.lithium.mixin.world.inline_block_access;

import net.caffeinemc.gradle.MixinConfigOption;