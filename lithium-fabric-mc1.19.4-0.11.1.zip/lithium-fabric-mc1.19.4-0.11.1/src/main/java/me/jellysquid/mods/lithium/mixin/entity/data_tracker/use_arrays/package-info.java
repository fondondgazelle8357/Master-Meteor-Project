@MixinConfigOption(description = "Data trackers use a custom optimized entry map")
package me.jellysquid.mods.lithium.mixin.entity.data_tracker.use_arrays;

import net.caffeinemc.gradle.MixinConfigOption;