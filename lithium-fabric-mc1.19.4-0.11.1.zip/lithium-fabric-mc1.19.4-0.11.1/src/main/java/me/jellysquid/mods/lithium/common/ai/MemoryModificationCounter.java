package me.jellysquid.mods.lithium.common.ai;

public interface MemoryModificationCounter {

    long getModCount();
}
