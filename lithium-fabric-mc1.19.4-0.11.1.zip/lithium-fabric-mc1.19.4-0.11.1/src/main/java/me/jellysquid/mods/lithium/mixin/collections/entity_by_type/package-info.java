@MixinConfigOption(description = "Uses fastutil hashmaps for type specific entity lists")
package me.jellysquid.mods.lithium.mixin.collections.entity_by_type;

import net.caffeinemc.gradle.MixinConfigOption;