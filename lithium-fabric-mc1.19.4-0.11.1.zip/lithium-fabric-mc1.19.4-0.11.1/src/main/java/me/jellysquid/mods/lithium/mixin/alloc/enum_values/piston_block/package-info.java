@MixinConfigOption(description = "Avoid `Enum#values()` array copy in frequently called code")
package me.jellysquid.mods.lithium.mixin.alloc.enum_values.piston_block;

import net.caffeinemc.gradle.MixinConfigOption;