@MixinConfigOption(description = "Skip repeatedly writing to the data tracker that an entity is not flying")
package me.jellysquid.mods.lithium.mixin.entity.fast_elytra_check;

import net.caffeinemc.gradle.MixinConfigOption;