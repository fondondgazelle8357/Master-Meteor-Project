@MixinConfigOption(description = "Allows access to existing BlockEntities without creating new ones")
package me.jellysquid.mods.lithium.mixin.util.block_entity_retrieval;

import net.caffeinemc.gradle.MixinConfigOption;