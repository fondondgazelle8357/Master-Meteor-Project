@MixinConfigOption(description = "Mob Tasks which search for POIs use the optimized POI search")
package me.jellysquid.mods.lithium.mixin.ai.poi.tasks;

import net.caffeinemc.gradle.MixinConfigOption;