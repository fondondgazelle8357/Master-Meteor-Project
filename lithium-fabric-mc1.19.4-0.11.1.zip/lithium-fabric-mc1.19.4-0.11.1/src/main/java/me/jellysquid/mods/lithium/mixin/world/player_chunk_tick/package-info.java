@MixinConfigOption(description = "Batches sending chunks to player together by replacing the corresponding code")
package me.jellysquid.mods.lithium.mixin.world.player_chunk_tick;

import net.caffeinemc.gradle.MixinConfigOption;