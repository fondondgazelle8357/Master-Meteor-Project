@MixinConfigOption(description = "Various collection optimizations")
package me.jellysquid.mods.lithium.mixin.collections;

import net.caffeinemc.gradle.MixinConfigOption;