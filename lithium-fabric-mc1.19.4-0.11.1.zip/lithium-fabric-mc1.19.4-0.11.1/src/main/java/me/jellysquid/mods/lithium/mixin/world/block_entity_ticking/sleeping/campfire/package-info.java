@MixinConfigOption(description = "BlockEntity sleeping for inactive campfires")
package me.jellysquid.mods.lithium.mixin.world.block_entity_ticking.sleeping.campfire;

import net.caffeinemc.gradle.MixinConfigOption;