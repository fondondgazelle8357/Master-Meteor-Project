@MixinConfigOption(description = "Uses fastutil hashmaps for AI memories and sensors")
package me.jellysquid.mods.lithium.mixin.collections.brain;

import net.caffeinemc.gradle.MixinConfigOption;