@MixinConfigOption(description = "BlockEntity sleeping for inactive brewing stands")
package me.jellysquid.mods.lithium.mixin.world.block_entity_ticking.sleeping.brewing_stand;

import net.caffeinemc.gradle.MixinConfigOption;