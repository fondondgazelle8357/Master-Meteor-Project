@MixinConfigOption(description = "Implements a faster POI search")
package me.jellysquid.mods.lithium.mixin.ai.poi;

import net.caffeinemc.gradle.MixinConfigOption;