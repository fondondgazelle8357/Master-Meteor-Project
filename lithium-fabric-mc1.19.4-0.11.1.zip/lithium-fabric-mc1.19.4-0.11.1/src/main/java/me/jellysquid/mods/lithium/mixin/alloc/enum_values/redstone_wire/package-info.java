@MixinConfigOption(description = "Avoid `Enum#values()` array copy in frequently called code")
package me.jellysquid.mods.lithium.mixin.alloc.enum_values.redstone_wire;

import net.caffeinemc.gradle.MixinConfigOption;