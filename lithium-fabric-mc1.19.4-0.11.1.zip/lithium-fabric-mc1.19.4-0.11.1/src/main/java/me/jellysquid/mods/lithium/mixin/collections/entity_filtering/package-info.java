@MixinConfigOption(description = "The expensive check to see if a TypeFilterableList can be filtered by a specific class is only made when a new list for that type needs to be created")
package me.jellysquid.mods.lithium.mixin.collections.entity_filtering;

import net.caffeinemc.gradle.MixinConfigOption;