@MixinConfigOption(description = "Keep track of running and runnable tasks to speed up task launching checks")
package me.jellysquid.mods.lithium.mixin.ai.task.launch;

import net.caffeinemc.gradle.MixinConfigOption;