@MixinConfigOption(description = "Optimizes chunk palette compaction when serializing chunks")
package me.jellysquid.mods.lithium.mixin.chunk.serialization;

import net.caffeinemc.gradle.MixinConfigOption;