@MixinConfigOption(description = "Avoid indirection and inline several functions in Direction, Axis and Box code")
package me.jellysquid.mods.lithium.mixin.math.fast_util;

import net.caffeinemc.gradle.MixinConfigOption;