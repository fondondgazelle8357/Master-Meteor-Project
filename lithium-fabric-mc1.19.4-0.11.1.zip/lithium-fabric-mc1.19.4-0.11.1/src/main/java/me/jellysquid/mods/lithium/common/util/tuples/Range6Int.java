package me.jellysquid.mods.lithium.common.util.tuples;

public record Range6Int(int negativeX, int negativeY, int negativeZ, int positiveX, int positiveY, int positiveZ) {
}
