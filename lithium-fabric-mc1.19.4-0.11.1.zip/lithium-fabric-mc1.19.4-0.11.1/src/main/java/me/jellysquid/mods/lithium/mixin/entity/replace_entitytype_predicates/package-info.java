@MixinConfigOption(description = "Accesses entities of the correct type directly instead of accessing all nearby entities and filtering them afterwards")
package me.jellysquid.mods.lithium.mixin.entity.replace_entitytype_predicates;

import net.caffeinemc.gradle.MixinConfigOption;