@MixinConfigOption(description = "Various world related optimizations")
package me.jellysquid.mods.lithium.mixin.world;

import net.caffeinemc.gradle.MixinConfigOption;