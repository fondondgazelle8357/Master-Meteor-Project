/**
 * This package includes patches that are meant to reduce the performance impact of Mob AI.
 */
@MixinConfigOption(description = "Mob AI optimizations")
package me.jellysquid.mods.lithium.mixin.ai;

import net.caffeinemc.gradle.MixinConfigOption;