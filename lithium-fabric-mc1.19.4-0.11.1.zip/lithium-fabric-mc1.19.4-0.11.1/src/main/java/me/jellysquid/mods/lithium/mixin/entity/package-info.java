@MixinConfigOption(description = "Various entity optimizations")
package me.jellysquid.mods.lithium.mixin.entity;

import net.caffeinemc.gradle.MixinConfigOption;