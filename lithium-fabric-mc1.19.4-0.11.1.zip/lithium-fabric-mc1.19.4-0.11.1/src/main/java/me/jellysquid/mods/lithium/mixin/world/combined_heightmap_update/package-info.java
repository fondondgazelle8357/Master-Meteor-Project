@MixinConfigOption(description = "The four vanilla heightmaps are updated using a combined block search instead of searching blocks separately.")
package me.jellysquid.mods.lithium.mixin.world.combined_heightmap_update;

import net.caffeinemc.gradle.MixinConfigOption;