package me.jellysquid.mods.lithium.common.hopper;

public interface BlockStateOnlyInventory {
}
