@MixinConfigOption(description = "Remove unnecessary locking when accessing the data tracker")
package me.jellysquid.mods.lithium.mixin.entity.data_tracker.no_locks;

import net.caffeinemc.gradle.MixinConfigOption;