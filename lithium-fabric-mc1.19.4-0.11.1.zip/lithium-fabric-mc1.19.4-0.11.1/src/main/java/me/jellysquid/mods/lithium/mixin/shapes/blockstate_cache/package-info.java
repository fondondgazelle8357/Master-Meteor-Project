@MixinConfigOption(description = "Use a faster collection for the full cube test cache")
package me.jellysquid.mods.lithium.mixin.shapes.blockstate_cache;

import net.caffeinemc.gradle.MixinConfigOption;