@MixinConfigOption(description = "An optimized chunk cache is used for world population features which avoids array indirection and complex logic")
package me.jellysquid.mods.lithium.mixin.gen.chunk_region;

import net.caffeinemc.gradle.MixinConfigOption;