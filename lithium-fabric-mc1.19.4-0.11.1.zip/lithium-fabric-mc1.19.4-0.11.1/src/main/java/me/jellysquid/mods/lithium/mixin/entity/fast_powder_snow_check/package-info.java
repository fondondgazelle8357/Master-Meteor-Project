@MixinConfigOption(description = "Skip checking whether an entity is inside powder snow for movement speed slowdown when it is not freezing")
package me.jellysquid.mods.lithium.mixin.entity.fast_powder_snow_check;

import net.caffeinemc.gradle.MixinConfigOption;