@MixinConfigOption(description = "Uses fastutil hashmaps for BlockEntity tickers")
package me.jellysquid.mods.lithium.mixin.collections.block_entity_tickers;

import net.caffeinemc.gradle.MixinConfigOption;