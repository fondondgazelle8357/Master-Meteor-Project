@MixinConfigOption(description = "BlockEntity sleeping for inactive furnaces")
package me.jellysquid.mods.lithium.mixin.world.block_entity_ticking.sleeping.furnace;

import net.caffeinemc.gradle.MixinConfigOption;