@MixinConfigOption(description = "Skip hand swinging speed and animation calculations when the hand of an entity is not swinging")
package me.jellysquid.mods.lithium.mixin.entity.fast_hand_swing;

import net.caffeinemc.gradle.MixinConfigOption;