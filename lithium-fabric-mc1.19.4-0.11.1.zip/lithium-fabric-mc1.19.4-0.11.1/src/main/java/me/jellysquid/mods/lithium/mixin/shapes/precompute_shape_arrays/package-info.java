@MixinConfigOption(description = "VoxelShapes store position arrays for their shape instead of recalculating the positions")
package me.jellysquid.mods.lithium.mixin.shapes.precompute_shape_arrays;

import net.caffeinemc.gradle.MixinConfigOption;