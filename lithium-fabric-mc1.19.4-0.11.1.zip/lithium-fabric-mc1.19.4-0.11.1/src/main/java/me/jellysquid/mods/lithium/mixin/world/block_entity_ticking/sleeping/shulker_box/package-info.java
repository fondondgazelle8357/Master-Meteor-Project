@MixinConfigOption(description = "BlockEntity sleeping for closed shulker boxes")
package me.jellysquid.mods.lithium.mixin.world.block_entity_ticking.sleeping.shulker_box;

import net.caffeinemc.gradle.MixinConfigOption;