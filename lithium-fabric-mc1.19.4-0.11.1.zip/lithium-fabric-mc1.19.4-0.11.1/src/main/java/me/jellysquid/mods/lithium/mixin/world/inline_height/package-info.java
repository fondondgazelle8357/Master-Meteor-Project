@MixinConfigOption(description = "Reduces indirection by inlining world height access methods")
package me.jellysquid.mods.lithium.mixin.world.inline_height;

import net.caffeinemc.gradle.MixinConfigOption;