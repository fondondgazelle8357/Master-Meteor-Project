package me.jellysquid.mods.lithium.common.entity.movement_tracker;

public interface ToggleableMovementTracker {

    int setNotificationMask(int notificationMask);
}
