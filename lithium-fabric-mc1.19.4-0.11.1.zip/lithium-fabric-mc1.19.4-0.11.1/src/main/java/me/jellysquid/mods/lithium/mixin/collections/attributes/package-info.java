@MixinConfigOption(description = "Uses fastutil hashmaps for entity attributes")
package me.jellysquid.mods.lithium.mixin.collections.attributes;

import net.caffeinemc.gradle.MixinConfigOption;