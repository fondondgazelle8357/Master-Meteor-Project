@MixinConfigOption(description = "Certain BlockEntity Inventories emit updates to their listeners when their stack list is changed or the inventory becomes invalid")
package me.jellysquid.mods.lithium.mixin.util.inventory_change_listening;

import net.caffeinemc.gradle.MixinConfigOption;