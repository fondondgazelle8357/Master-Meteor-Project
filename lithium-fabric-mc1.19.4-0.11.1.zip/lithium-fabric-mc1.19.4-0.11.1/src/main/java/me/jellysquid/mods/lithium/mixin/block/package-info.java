@MixinConfigOption(description = "Optimizations related to blocks")
package me.jellysquid.mods.lithium.mixin.block;

import net.caffeinemc.gradle.MixinConfigOption;