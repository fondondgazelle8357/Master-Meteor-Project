@MixinConfigOption(description = "Avoid indirection when accessing the profiler")
package me.jellysquid.mods.lithium.mixin.profiler;

import net.caffeinemc.gradle.MixinConfigOption;