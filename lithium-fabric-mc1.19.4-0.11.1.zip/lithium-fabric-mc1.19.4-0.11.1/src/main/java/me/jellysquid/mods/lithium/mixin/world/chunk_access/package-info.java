@MixinConfigOption(description = "Several changes to the chunk manager to speed up chunk access")
package me.jellysquid.mods.lithium.mixin.world.chunk_access;

import net.caffeinemc.gradle.MixinConfigOption;