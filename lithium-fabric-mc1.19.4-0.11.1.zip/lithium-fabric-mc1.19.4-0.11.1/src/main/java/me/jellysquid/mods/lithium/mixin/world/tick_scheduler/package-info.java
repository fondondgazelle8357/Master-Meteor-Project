@MixinConfigOption(description = "Use faster tick collections and pack scheduled ticks into integers for easier tick comparisons")
package me.jellysquid.mods.lithium.mixin.world.tick_scheduler;

import net.caffeinemc.gradle.MixinConfigOption;