@MixinConfigOption(description = "Avoids stream code in suffocation check")
package me.jellysquid.mods.lithium.mixin.entity.collisions.suffocation;

import net.caffeinemc.gradle.MixinConfigOption;