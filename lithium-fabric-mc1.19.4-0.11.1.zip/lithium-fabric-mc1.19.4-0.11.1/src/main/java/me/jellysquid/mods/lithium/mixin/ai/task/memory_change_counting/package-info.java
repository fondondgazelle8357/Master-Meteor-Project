@MixinConfigOption(description = "Keep track of AI memory changes to skip checking AI task memory prerequisites")
package me.jellysquid.mods.lithium.mixin.ai.task.memory_change_counting;

import net.caffeinemc.gradle.MixinConfigOption;