package me.jellysquid.mods.lithium.common.entity;

public interface EquipmentEntity {
    default void lithiumOnEquipmentChanged() {
    }

    interface EquipmentTrackingEntity {
    }
}
