@MixinConfigOption(
        description = "Removes the 1024 entry biome temperature cache hash map because the cache seems to be slow and rarely hit."
)
package me.jellysquid.mods.lithium.mixin.world.temperature_cache;

import net.caffeinemc.gradle.MixinConfigOption;