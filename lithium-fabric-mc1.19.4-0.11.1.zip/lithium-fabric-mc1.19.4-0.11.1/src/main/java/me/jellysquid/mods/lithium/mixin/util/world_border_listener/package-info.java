@MixinConfigOption(description = "World border changes are sent to listeners such as BlockEntities")
package me.jellysquid.mods.lithium.mixin.util.world_border_listener;

import net.caffeinemc.gradle.MixinConfigOption;