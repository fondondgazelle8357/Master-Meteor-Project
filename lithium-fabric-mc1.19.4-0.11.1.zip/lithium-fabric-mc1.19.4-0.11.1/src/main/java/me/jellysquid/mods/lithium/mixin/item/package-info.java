@MixinConfigOption(description = "Item stacks use the cached empty flag")
package me.jellysquid.mods.lithium.mixin.item;

import net.caffeinemc.gradle.MixinConfigOption;