@MixinConfigOption(description = "Skip bounds validation when accessing blocks")
package me.jellysquid.mods.lithium.mixin.chunk.no_validation;

import net.caffeinemc.gradle.MixinConfigOption;