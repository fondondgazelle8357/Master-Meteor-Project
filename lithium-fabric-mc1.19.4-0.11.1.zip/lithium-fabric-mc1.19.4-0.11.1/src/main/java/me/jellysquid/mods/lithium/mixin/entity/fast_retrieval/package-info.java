@MixinConfigOption(description = "Access entities faster when accessing a relatively small number of entity sections")
package me.jellysquid.mods.lithium.mixin.entity.fast_retrieval;

import net.caffeinemc.gradle.MixinConfigOption;