@MixinConfigOption(description = "Hopper minecarts search for item entities faster by combining multiple item entity searches. Also eliminates duplicated item entity pickup attempts")
package me.jellysquid.mods.lithium.mixin.entity.hopper_minecart;

import net.caffeinemc.gradle.MixinConfigOption;